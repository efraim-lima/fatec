import whirlpool
a = raw_input("Digite a string: ")
j = whirlpool.new(a).hexdigest()
print "Hash = ", j


