from Crypto.Cipher import AES
import Padding
import hashlib
import socket
import sys

def send_data():
    # Send data
    iv = '0123456789ABCDEF'
    message = raw_input("Write the message: ")
    senha = 'senha'
    senha1 = hashlib.sha256(senha).digest()
    aes1 = AES.new(senha1, AES.MODE_CFB, iv)
    plaintext = Padding.appendPadding(message,blocksize=Padding.AES_blocksize,mode=0)
    cipher_text = aes1.encrypt(plaintext)
    cipher_text_hex = cipher_text.encode('hex')
    print 'Ciphered text: ', cipher_text_hex
    print >>sys.stderr, 'sending "%s"' % cipher_text_hex
    sock.sendall(cipher_text_hex)
    #data = sock.recv(65536)
    #print >>sys.stderr, 'received "%s"' % data
    if message == 'close all':
        finally_connection()
    else:
        send_data()

def finally_connection():
    print >>sys.stderr, 'closing socket'
    sock.close()

# Create a TCP/IP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect the socket to the port where the server is listening
server_address = ('localhost', 10000)
print >>sys.stderr, 'connecting to %s port %s' % server_address
sock.connect(server_address)

try:
    send_data()

finally:
   finally_connection()